function sendMessage() {
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    if (userInput.value.trim() !== '') {
        // Affiche le message de l'utilisateur
        const userMessage = document.createElement('div');
        userMessage.className = 'user-message';
        userMessage.textContent = userInput.value;
        chatBox.appendChild(userMessage);

        // Réponse simulée de l'IA (vous pouvez la remplacer par une vraie API)
        const botMessage = document.createElement('div');
        botMessage.className = 'bot-message';
        botMessage.textContent = 'Bonjour, je suis votre assistant virtuel ! Comment puis-je vous aider ?';
        chatBox.appendChild(botMessage);

        // Réinitialise l'entrée de l'utilisateur
        userInput.value = '';
        
        // Scroller vers le bas automatiquement
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}
